OAuth 1.0
=========

OAuth 1.0 is the standardization and combined wisdom of many well established industry protocols
at its creation time. It was first introduced as Twitter's open protocol. It is similar to other protocols
at that time in use (Google AuthSub, AOL OpenAuth, Yahoo BBAuth, Upcoming API, Flickr API, etc).

If you are creating an open platform, AUTHLIB ENCOURAGE YOU USE OAUTH 2.0 INSTEAD.

.. toctree::
    :maxdepth: 2

    intro
